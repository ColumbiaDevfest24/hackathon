#database file for storing nonprofit organizations' information
from django.db import models

class Organization(models.Model)
#attributes to add later: org name, their website, location (address), contact info, sponsors(?), daily hours, etc.
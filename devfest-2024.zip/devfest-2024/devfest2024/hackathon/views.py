from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(response):
    return render(response, "main/base.html", {})
def volunteer(response):
    return.user
    return HttpResponse("<h1> How to get involved </h1>")

def home(response):
    return render(response, "main/home.html")
def help(response):
    return render(response, "main/needhelp.html")
  #need to import needhelp.html from the other repository so this displays from that
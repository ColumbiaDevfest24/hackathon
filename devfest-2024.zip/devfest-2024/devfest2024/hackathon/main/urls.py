from django.urls import path

from . import views

urlpatterns = [
path("", views.index, name="index" ),
path('',include("django.contrib.auth.urls")),
path("volunteer/", views.volunteer, name="volunteer"),
path("help/", views.help, name="help"), 
  #views.help does not yet exist, so we need to create it
]